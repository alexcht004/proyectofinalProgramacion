
package proyectoBaseDeDatos;

import Controlador.CtrlProducto;
import Controlador.CtrlCliente;

import Controlador.ctrlEmpleados;


import Modelo.Cliente;
import Modelo.Empleados;
import Modelo.controlBaseDeDatos;
import Modelo.Producto;



import Vista.frmCliente;
import Vista.frmEmpleado;

import Vista.frmProducto;
import Vista.menu;


import java.util.Scanner;
import javax.swing.JOptionPane;


public class ProyectoBaseDeDatos {
    
   
    public static void main(String[] args){
        
         menu m=new menu();
         m.main(args);
       
    }
    
}

    
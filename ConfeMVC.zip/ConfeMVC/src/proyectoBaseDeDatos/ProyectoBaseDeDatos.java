
package proyectoBaseDeDatos;

import Controlador.CtrlProducto;
import Controlador.CtrlCliente;


import Modelo.Cliente;
import Modelo.Producto;


import Vista.frmCliente;
import Vista.frmProducto;
import Vista.menu;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class ProyectoBaseDeDatos {
    
   
    public static void main(String[] args){
        
         menu m=new menu();
         m.main(args);
       
    }
    
}

    